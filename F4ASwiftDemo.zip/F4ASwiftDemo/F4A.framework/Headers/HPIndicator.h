//
//
//  Created by RAJA JIMSEN on 03/03/17.
//  Copyright © 2017 RAJA JIMSEN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface HPIndicator : NSObject

+(void)StartHPLoading:(UIView*)GetCurrentview;
+(void)StopHPLoading;

@end
