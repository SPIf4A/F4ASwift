//
//  DemoFramework.h
//  DemoFramework
//
//  Created by RAJA JIMSEN on 02/05/18.
//  Copyright © 2018 RAJA JIMSEN. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DemoFramework.
FOUNDATION_EXPORT double DemoFrameworkVersionNumber;

//! Project version string for DemoFramework.
FOUNDATION_EXPORT const unsigned char DemoFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DemoFramework/PublicHeader.h>
//#import <DemoFramework/ESpDemo.h>
#import <DemoFramework/FantasyManager.h>



