//
//  ESpDemo.h
//  DemoFramework
//
//  Created by RAJA JIMSEN on 02/05/18.
//  Copyright © 2018 RAJA JIMSEN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ESpDemo : NSObject

+(void)PrintSample;

@end
