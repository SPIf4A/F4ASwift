//
//  ContestCell.h
//  E-Sports
//
//  Created by RAJA JIMSEN on 26/04/18.
//  Copyright © 2018 RAJA JIMSEN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContestCell : UITableViewCell

@property(nonatomic,strong) IBOutlet UILabel * TitleLbl;
@property(nonatomic,strong) IBOutlet UILabel * DescLbl;
@property(nonatomic,strong) IBOutlet UILabel * FeeLbl;
@property(nonatomic,strong) IBOutlet UIImageView * IconImg;
@property(nonatomic,strong) IBOutlet UIButton * PlayBtn;
@property(nonatomic,strong) IBOutlet UILabel * PrizeLbl;







@end
