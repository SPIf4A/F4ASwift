//
//  F4A-bridging.h
//  F4ASwiftDemo
//
//  Created by Raja on 23/09/2018.
//  Copyright © 2018 Raja. All rights reserved.
//

#ifndef F4A_bridging_h
#define F4A_bridging_h

#import <F4A/FantasyManager.h>


#endif /* F4A_bridging_h */
